//
//  ViewController.swift
//  searchBarDemo1
//
//  Created by Mac on 5/24/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
  
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tblView: UITableView!
    
    var aryData = ["Arjun kapoor","Varun dhawan","Shahrukhan","Salman Khan","Amitabh Bachhan","Amir khan","Anil kapoor","Sonam kapoor","Pareeniti Chopra","Virat kohli","Aishwarya ray Bachhan","Prachi Desai","Diya mirza","Kangana Ranaut","Deepika Padukone","Alia Bhatt.","Sunny Leone","Kareena Kapoor Khan","Kriti Sanon","Ranveer Sinh","Ranbir","Disha Patni","Alu Arjun"]
    
    var filterAry = [""]

    override func viewDidLoad() {
        super.viewDidLoad()
      
        searchBar.delegate = self
        tblView.delegate = self
        filterAry = aryData
        
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterAry.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        if cell == nil {
            cell = UITableViewCell.init(style: .subtitle, reuseIdentifier: "cell")
        }
        cell?.textLabel?.text = filterAry[indexPath.row]
        
        return  cell!
    
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filterAry = searchText.isEmpty ? aryData : aryData.filter { (item: String) -> Bool in
            
            return item.range(of: searchText, options: .anchored , range: nil, locale: nil) != nil
        }
        tblView.reloadData()
    }
}

